import React, { Component } from 'react';
import './App.css';
import axios from 'axios';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      description: '',
      selectedFile: '',
      imageView : ''
    };
  }
  onChange = (e) => {
      if(e.target.name == 'selectedFile'){
        this.setState({
          selectedFile: e.target.files[0]
        })
      }else{
        this.setState({ [e.target.name]: e.target.value });
      }
  }

  onSubmit = (e) => {
    e.preventDefault();
    const { description, selectedFile } = this.state;
    let formData = new FormData();

    formData.append('description', description);
    formData.append('selectedFile', selectedFile);

      axios.post('http://localhost:3001/', formData)
        .then((result) => {
          // access results...
        });

  }

  handleGetPhoto = (e) => {
      axios.post('http://localhost:3001/download/'+'test.jpg')
        .then(response => {
            console.log("Imgae Res : ",response);
            let imagePreview = 'data:image/jpg;base64, ' + response.data;
            this.setState({
                imageView: imagePreview
            })
        });
  }
  render() {
    const { description, selectedFile } = this.state;
        return (
          <div>
          <form onSubmit={this.onSubmit}>
            <input
              type="text"
              name="description"
              value={description}
              onChange={this.onChange}
              multiple
            />
            <input
              type="file"
              name="selectedFile"
              onChange={this.onChange}
            />
            <button type="submit">Submit</button>
          </form>
          <div>
            <button onClick = {this.handleGetPhoto}>Get Photo</button>
          </div>
            <div>
              <img src = {this.state.imageView}/>
            </div>
          </div>
        )
  }
}

export default App;
